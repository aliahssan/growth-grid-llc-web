import { NextResponse } from "next/server";

import { auth } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { createPresignedUpload } from "@/lib/uploads";

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const limit = rateLimit(`upload:${session.user.id}`, 5, 60_000);
  if (!limit.success) {
    return NextResponse.json(
      { error: "Too many upload requests" },
      { status: 429 },
    );
  }

  const { type } = await request.json();
  if (typeof type !== "string" || !type) {
    return NextResponse.json(
      { error: "Content type is required" },
      { status: 400 },
    );
  }

  try {
    const presigned = await createPresignedUpload(type);
    return NextResponse.json(presigned);
  } catch (error) {
    console.error("Presign failed", error);
    return NextResponse.json(
      { error: "Unable to create upload URL" },
      { status: 500 },
    );
  }
}

